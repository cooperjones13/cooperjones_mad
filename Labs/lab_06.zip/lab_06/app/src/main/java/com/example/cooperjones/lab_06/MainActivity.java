package com.example.cooperjones.lab_06;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    EditText editName;
    EditText editEmail;
    EditText editDOB;
    Spinner spinner;
    Switch switchNotif;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editName = findViewById(R.id.editName);
        editEmail = findViewById(R.id.editEmail);
        editDOB = findViewById(R.id.editDOB);
        switchNotif = findViewById(R.id.switchNotif);
        spinner = findViewById(R.id.spinner);

    }

    public void createAccount(View view){
        Intent intent = new Intent(this, DisplayAccount.class);
        String name = editName.getText().toString();
        String email = editEmail.getText().toString();
        String dob = editDOB.getText().toString();
        Boolean notif = switchNotif.isChecked();
        String gender = spinner.getSelectedItem().toString();

        intent.putExtra("name", name);
        intent.putExtra("email", email);
        intent.putExtra("dob", dob);
        intent.putExtra("gender", gender);
        intent.putExtra("notif", notif);

        startActivity(intent);
    }
}

package com.example.cooperjones.cooper_mad_exam;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

public class SuggestPizza extends AppCompatActivity {

    String rec;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_suggest_pizza);

        Intent intent = getIntent();
        rec = intent.getStringExtra(MainActivity.KEY);

        TextView disp = findViewById(R.id.display);
        disp.setText(rec);
    }

    public void onSubmit(View view){
        if(rec == getString(R.string.cosmos)){
            openWebPage("http://cosmospizza.com/");
        }
        else if(rec == getString(R.string.dp)){
            openWebPage("https://www.dpdough.com/");
        }
        else if(rec == getString(R.string.blp)){
            openWebPage("https://bossladypizza.com/");
        }

        Context context = getApplicationContext();
        String text = getString(R.string.webError);
        int duration = Toast.LENGTH_SHORT;

        Toast toast = Toast.makeText(context, text, duration);
        toast.show();
    }

    public void openWebPage(String url) {
        Uri webpage = Uri.parse(url);
        Intent intent = new Intent(Intent.ACTION_VIEW, webpage);
        if (intent.resolveActivity(getPackageManager()) != null) {
            startActivity(intent);
        }
    }
}

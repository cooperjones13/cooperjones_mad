package com.example.cooperjones.cooper_mad_exam;

import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ToggleButton;

public class MainActivity extends AppCompatActivity {

    public static final String KEY = "suggestion";

    EditText pizzaName;
    ToggleButton toggleSauce;
    Switch switchGF;
    CheckBox checkPep;
    CheckBox checkMush;
    CheckBox checkSsg;
    Spinner sizeSpinner;

    TextView display;

    Button suggest;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        pizzaName = findViewById(R.id.pizzaName);
        toggleSauce = findViewById(R.id.toggleSauce);
        switchGF = findViewById(R.id.switchGF);

        checkPep = findViewById(R.id.checkPep);
        checkMush = findViewById(R.id.checkMush);
        checkSsg = findViewById(R.id.checkSausage);

        sizeSpinner = findViewById(R.id.spinnerSize);

        display = findViewById(R.id.displayPizza);

        suggest = findViewById(R.id.suggestButton);
        suggest.setVisibility(View.GONE);
    }

    public void generatePizza(View view){
        String toppings = "";

        if(checkPep.isChecked()){
            toppings += " " + checkPep.getText();
        }

        if(checkMush.isChecked()){
            toppings += " " + checkMush.getText();
        }

        if(checkSsg.isChecked()){
            toppings += " " + checkSsg.getText();
        }

        if(toppings.length() == 0){
            toppings = " No Toppings";
        }

        String gf = "";
        if(switchGF.isChecked()){
            gf += switchGF.getText() + " ";
        }

        String displayText = pizzaName.getText() + ": "+ sizeSpinner.getSelectedItem().toString() + " "+  gf +  "Pizza with" + toppings + " and " + toggleSauce.getText() + " Sauce";

        if(pizzaName.getText().length() == 0){
            Context context = getApplicationContext();
            String text = getString(R.string.nameError);
            int duration = Toast.LENGTH_SHORT;

            Toast toast = Toast.makeText(context, text, duration);
            toast.show();
        }
        else{
            display.setText(displayText);
            suggest.setVisibility(View.VISIBLE);
        }


    }


    public void suggestRestaurant(View view){
        String rec;
        if(switchGF.isChecked()){
            rec = getString(R.string.blp);
        }
        else if(!toggleSauce.isChecked()){
            rec = getString(R.string.dp);
        }
        else{
            rec = getString(R.string.cosmos);
        }

        Intent intent = new Intent(this, SuggestPizza.class);

        intent.putExtra(KEY, rec);
        startActivity(intent);
    }

}

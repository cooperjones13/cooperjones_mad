package com.example.cooperjones.lab_06;

import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

public class DisplayAccount extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display_account);

        Intent intent = getIntent();
        String name = intent.getStringExtra("name");
        String email = intent.getStringExtra("email");
        String dob = intent.getStringExtra("dob");
        String gender = intent.getStringExtra("gender");
        Boolean notif = intent.getBooleanExtra("notif", false);

        TextView dispName = findViewById(R.id.name);
        dispName.setText(name);
        TextView dispEmail = findViewById(R.id.email);
        dispEmail.setText(email);
        TextView dispDob = findViewById(R.id.dob);
        dispDob.setText(dob);
        TextView dispGender = findViewById(R.id.gender);
        dispGender.setText(gender);

        Context context = getApplicationContext();
        String text = "Account Created";
        int duration = Toast.LENGTH_SHORT;

        Toast toast = Toast.makeText(context,text,duration);
        toast.show();







    }
}
